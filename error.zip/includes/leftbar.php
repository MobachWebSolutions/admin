	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
			<li><a href="userlist.php"><i class="fa fa-users"></i> Userlist</a>
			</li>
			<li><a href="profile.php"><i class="fa fa-user"></i> &nbsp;Profile</a>
			</li>
            <li><a href="register.php"><i class="fa fa-user-plus"></i> &nbsp;Register User</a>
			</li>
			</ul>
			<p class="text-center" style="color:#ffffff; margin-top: 100px;">© Breauke Panel and Dash <br>Part of <a href="https://mobachwebsolutions.com" target="_blank">MWS</a></p>
		</nav>

		