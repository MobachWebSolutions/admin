$(document).ready(function(){
	
	Cufon.replace('h1, #bestel #right .countdown h2',{
		fontFamily: 'Scala Sans'
	});
	
	Cufon.replace('.deal h2',{
		fontFamily: 'Segoe Print'
	});
		
});
