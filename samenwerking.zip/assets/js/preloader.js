$(window).load(function() {
	$(".preloader-wrapper").delay(2000).fadeOut("slow");
  $(".preloader").delay(2000).fadeOut("slow");
})