$(document).ready(function() {
    $('#content').load('index.html');
})