<?php
$db_server = "localhost";
$db_username = "breauke";
$db_password = "Mob#sam32!";
$db_database = "breauke";
     
$name=$_POST['name'];
$email=$_POST['email'];
$password=md5($_POST['password']);
$title=$_POST['title'];
$phone=$_POST['mobileno'];
$status='1';
     
$conn = new PDO("mysql:host=$db_server;dbname=$db_database", $db_username, $db_password);
     
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$sql = "INSERT INTO users (name, email, password, mobile, title, status)
VALUES ('$name', '$email', '$password', '$phone', '$title', '$status')";
     
$conn->exec($sql);
echo "<script>alert('Account successfully added!'); window.location='register.php'</script>";
?>