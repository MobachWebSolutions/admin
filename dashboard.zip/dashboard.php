<?php
session_start();
error_reporting(0);
include('includes/config.php');
if(strlen($_SESSION['alogin'])==0)
	{	
header('location:index.php');
}
else{
?>
<!doctype html>
<html>
<head>
    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />
    <!-- Keywords -->
    <meta name="description" content="" />
	<meta name="keywords" content="" />
	<meta name="author" content="" />
    <!-- Title -->
    <title>Dashboard - breaukedash</title>
    <!-- Icons -->
    <link rel="apple-touch-icon" sizes="57x57" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="60x60" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="72x72" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="76x76" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="114x114" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="120x120" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="144x144" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="152x152" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="a7a2627860c8c7a6ce511857833c48f8.ico/apple-icon-180x180.png">
    <link rel="icon" type="image/png" sizes="192x192" href="a7a2627860c8c7a6ce511857833c48f8.ico/android-icon-192x192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="a7a2627860c8c7a6ce511857833c48f8.ico/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="a7a2627860c8c7a6ce511857833c48f8.ico/favicon-96x96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="a7a2627860c8c7a6ce511857833c48f8.ico/favicon-16x16.png">
    <link rel="manifest" href="/manifest.json">
    <meta name="msapplication-TileColor" content="#556080">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#3d324c">
    <!-- Stylesheets -->
    
    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css?family=Poppins" rel="stylesheet">
    <!-- Responsive -->
    <link rel="stylesheet" href="assets/css/responsive.css">
    <!-- Style -->
    <link rel="stylesheet" href="assets/css/style.css">
    <!-- Fontawesome -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/themify-icons.css">
    <link rel="stylesheet" href="assets/css/metisMenu.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/slicknav.min.css">
</head>

<body>
    <!-- Main content -->
    <div class="wrapper">
        <!-- Sidebar -->
    <div id="sidebar">
        <nav>
            <div class="sidebar-header">
                <a href="dashboard.php"><img src="assets/img/Advocaat-Utrecht-152.png" class="headerimg"></a>
            </div>
            <ul class="metismenu" id="menu">
                            <li class="active">
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-dashboard" style="font-size: 20px;"></i><span>Dashboard</span></a>
                                <ul class="collapse">
                                    <li><a href="dashboard.php">Dashboard</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-archive" style="font-size: 20px;"></i><span>Verwerkings register
                                    </span></a>
                                <ul class="collapse">
                                    <li><a href="addregister.php">Voeg toe</a></li>
                                    <li><a href="viewregister.php">Bekijk register</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-settings" style="font-size: 20px;"></i><span>Categorieën</span></a>
                                <ul class="collapse">
                                    <li><a href="category/employees.php">Werknemers</a></li>
                                    <li><a href="category/zzp.php">ZZP'ers</a></li>
                                    <li><a href="category/clients.php">Klanten</a></li>
                                    <li><a href="category/students.php">Cursisten</a></li>
                                    <li><a href="category/visitors.php">Bezoekers website</a></li>
                                </ul>
                            </li>
                            <li>
                                <a href="javascript:void(0)" aria-expanded="true"><i class="ti-help" style="font-size: 20px;"></i><span>Help</span></a>
                                <ul class="collapse">
                                    <li><a href="faq.php">FAQ</a></li>
                                    <li><a href="contact.php">Contact</a></li>
                                </ul>
                            </li>
                        </ul>
        </nav>
    </div>
        <!-- Page content -->
        <div id="content">
            <div class="header-area">
                <div class="row align-items-center">
                    <div class="col-md-6 col-sm-8 clearfix">
                        <div class="container-fluid">
                            <button type="button" id="sidebarCollapse" class="btn btn-info">
                                <span></span>
                                <span></span>
                                <span></span>
                            </button>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-4 clearfix">
                        <ul class="notification-area pull-right">
                            <li id="full-view"><i class="ti-fullscreen" onClick="myFunction()"></i></li>
                            <li id="full-view-exit" ><i class="ti-zoom-out" onClick="myHide()"></i></li>
                            <li class="settings-btn"><i class="ti-help" onclick="openNav()"></i></li>
                        </ul>
                    </div>
                </div>
            </div>
                        <div class="page-title-area">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="breadcrumbs-area clearfix">
                            <h4 class="page-title pull-left">Dashboard</h4>
                            <ul class="breadcrumbs pull-left">
                                <li><a href="dashboard.php">Home</a></li>
                                <li><span>Dashboard</span></li>
                            </ul>
                        </div>
                    </div>
<?php
		$sql = "SELECT * from users;";
		$query = $dbh -> prepare($sql);
		$query->execute();
		$result=$query->fetch(PDO::FETCH_OBJ);
		$cnt=1;	
?>
                    <div class="col-sm-6 clearfix">
                        <div class="user-profile pull-right">
                            <img src="assets/img/user.svg" height="50px" style="margin-right: 10px">
                            <br>
                            <br>
                            <h4 class="user-name dropdown-toggle" data-toggle="dropdown"><?php echo htmlentities($result->name);?><i class="fa fa-angle-down"></i></h4>
                            <div class="dropdown-menu">
                                <a class="dropdown-item" href="profile.php">Help</a>
                                <a class="dropdown-item" href="profile.php">Profile</a>
                                <a class="dropdown-item" href="logout.php">Log Out</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <div class="main-content">
            
        </div>
        <footer>
            <div class="footer-area">
                <p>© Copyright 2019. All right reserved. Breauke Panel and Dash <br>Part of <a href="https://mobachwebsolutions.com" target="_blank">MWS</a></p>
            </div>
        </footer>
        
        </div>
        <div id="mySidenav" class="sidenav">
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            <div class="sidenavcontent">
                <ul class="nav offset-menu-tab">
            <li><a class="active" data-toggle="tab" href="#activity">FAQ</a></li>
            <li><a data-toggle="tab" href="#settings">Account</a></li>
        </ul>
        <div class="offset-content tab-content">
            <div id="activity" class="tab-pane fade in show active">
                <div class="recent-activity">
                </div>
            </div>
            <div id="settings" class="tab-pane fade">
                <div class="offset-settings">
                    <h4>Your Account</h4>
                    <div class="settings-list">
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Username:</h5>
                            </div>
                            <p><?php echo htmlentities($result->name);?></p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Email:</h5>
                            </div>
                            <p><?php echo htmlentities($result->email);?></p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Title:</h5>
                            </div>
                            <p><?php echo htmlentities($result->title);?></p>
                        </div>
                        <div class="s-settings">
                            <div class="s-sw-title">
                                <h5>Phone number:</h5>
                            </div>
                            <p><?php echo htmlentities($result->mobile);?></p>
                        </div>
                        <div class="s-settings">
                            <a class="btn-mws" href="logout.php">Log Out</a>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
            </div>
        </div>
    </div>
    <!-- Scripts -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script> 
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"></script>
    <!-- Menu -->
    <script>
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
    <!-- jquery latest version -->
    <script src="assets/js/vendor/jquery-2.2.4.min.js"></script>
    <!-- bootstrap 4 js -->
    <script src="assets/js/popper.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/owl.carousel.min.js"></script>
    <script src="assets/js/metisMenu.min.js"></script>
    <script src="assets/js/jquery.slimscroll.min.js"></script>
    <script src="assets/js/jquery.slicknav.min.js"></script>

    <!-- start chart js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.2/Chart.min.js"></script>
    <!-- start highcharts js -->
    <script src="https://code.highcharts.com/highcharts.js"></script>
    <!-- start zingchart js -->
    <script src="https://cdn.zingchart.com/zingchart.min.js"></script>
    <script>
    zingchart.MODULESDIR = "https://cdn.zingchart.com/modules/";
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "ee6b7db5b51705a13dc2339db3edaf6d"];
    </script>
    <!-- all line chart activation -->
    <script src="assets/js/line-chart.js"></script>
    <!-- all bar chart activation -->
    <script src="assets/js/bar-chart.js"></script>
    <!-- all pie chart -->
    <script src="assets/js/pie-chart.js"></script>
    <!-- others plugins -->
    <script src="assets/js/plugins.js"></script>
    <script src="assets/js/scripts.js"></script>
    <script>
        function openNav() {
            document.getElementById("mySidenav").style.width = "350px";
        }
        function closeNav() {
            document.getElementById("mySidenav").style.width = "0px";
        }
    </script>
</body>
</html>
<?php } ?>